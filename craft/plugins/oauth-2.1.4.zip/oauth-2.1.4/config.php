<?php

return [
    /**
     * Show CP section
     */
    'showCpSection' => true,

    /**
     * The URI segment Craft should look for when determining if the current request should first be routed to a
     * controller action.
     */
    'providerInfos' => [],
];