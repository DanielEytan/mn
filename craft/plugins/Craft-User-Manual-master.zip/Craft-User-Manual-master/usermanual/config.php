<?php
return [
    'pluginNameOverride' => null,
    'templateOverride' => null,
    'section' => null, // section ID (int) or handle (string)
];
